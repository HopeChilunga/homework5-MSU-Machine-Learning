clear;
clc;

X = load('data.txt');
y = load('labels.txt');

[m, n] = size(X);
X = [ones(m, 1) X];
initial_theta = zeros(n + 1, 1);


X_test=X(2000:end,:);
y_test = y(2000:end,:);

batch = [200, 500 , 800, 1000, 1500,2000]

accuracy = zeros(size(batch,2));

for i = 1:size(batch,2)
  options = optimset('GradObj', 'on', 'MaxIter', 400);

  [weights, fval, info, output, grad, hess] = fminunc(@(t)(costFunction(t, X(1:batch(i),:), y(1:batch(i),:))), initial_theta, options);
  p = predict(weights, X_test);
  accuracy(i) = mean(double(p == y_test)) * 100;
  fprintf('Train Accuracy [ n example = %f]: %f\n', batch(i) , accuracy(i));
  
end

plot(batch, accuracy);
ylabel("Accuracy (%)")
xlabel("Training set batch")
