clc
clear
load ad_data.mat
par=0:0.1:1;

training = zeros(size(par));
testing = zeros(size(par));

for i = 1:size(par,2)
   
  [w, c] = logistic_l1_train(X_train, y_train, par(i));
  
  training(i) = mean(double(predict(w, X_train) == y_train)) * 100;
  testing(i) = mean(double(predict(w, X_test) == y_test)) * 100;
  
##  fprintf('Par Argument on: %f\n', par(i));
##  fprintf('Train Accuracy: %f\n', training(i));
##  fprintf('Test Accuracy: %f\n', testing(i));
##  fprintf('----------------------------------------------------------------\n');
##  
  
end

hold on
plot(par, training)
plot(par, testing)
xlabel(" {\lambda} parameter")
ylabel("Accuracy")

legend("Training data", "Testing Data")
